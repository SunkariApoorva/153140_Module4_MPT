package com.capgemini.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.model.FeedBack;
import com.capgemini.model.Product;

public interface FeedBackProduct extends JpaRepository<Product, Integer> {

}
