package com.capgemini.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.model.FeedBack;
import com.capgemini.model.Product;
import com.capgemini.service.UserFeedBackService;

@RestController
public class FeedBackController implements ErrorController {

	@Autowired(required = true)
	private UserFeedBackService service;

	
	@RequestMapping(value = "/getFeedBack")
	public FeedBack getFeedBack(int id) {

		FeedBack feedback = service.getFeedback(id);

		return feedback;

	}
/*	@RequestMapping(value="/givefeedback",method=RequestMethod.POST)
	public FeedBack giveFeedBack(@RequestParam int pid,@RequestParam int cid,@RequestParam String Comments,@RequestParam int rating) {
		FeedBack feedback=new FeedBack();
		feedback.setComment(Comments);
		feedback.setRating(rating);
		feedback=service.giveFeedback(feedback,pid,cid);
		return feedback;
	}*/

	@RequestMapping(value="/givefeedback1",method=RequestMethod.GET)
	public FeedBack giveFeedBack1(int pid,int cid, String comment, int rating) {
		FeedBack feedback=new FeedBack();
		feedback.setComment(comment);
		feedback.setRating(rating);
		System.out.println(comment);
		feedback=service.giveFeedback(feedback,pid,cid);
		return feedback;
	}
	@Override
	public String getErrorPath() {
		// TODO Auto-generated method stub
		return null;
	}

}
