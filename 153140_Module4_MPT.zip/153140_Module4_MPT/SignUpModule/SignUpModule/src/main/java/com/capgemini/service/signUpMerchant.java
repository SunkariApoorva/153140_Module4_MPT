package com.capgemini.service;

import com.capgemini.model.Merchant;

public interface signUpMerchant {
	public String addMerchant(Merchant merchant);
	public Merchant findMerchantByid(int id);

}
