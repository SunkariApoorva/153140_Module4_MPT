package com.capgemini.test;

public class testcasesdummy {
//create individual test file in the test package don't write anything in this files
}
