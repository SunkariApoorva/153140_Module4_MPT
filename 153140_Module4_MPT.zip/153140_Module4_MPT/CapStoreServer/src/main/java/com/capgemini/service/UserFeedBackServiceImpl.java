package com.capgemini.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.capgemini.model.Customer;
import com.capgemini.model.FeedBack;
import com.capgemini.model.Product;
import com.capgemini.repository.FeedBackProduct;
import com.capgemini.repository.FeedBackRepository;

@Service("service")
public class UserFeedBackServiceImpl implements UserFeedBackService {
	@Autowired(required = true)
	FeedBackRepository repo;
	@Autowired(required = true)
	FeedBackProduct repo1;

	@Transactional
	@Override
	public FeedBack getFeedback(int id) {

		FeedBack feedback = repo.getFeedBack(id);
		return feedback;

	}

	@Override
	public FeedBack giveFeedback(FeedBack feedback, int pid, int cid) {
		feedback.setStartTime(Date.valueOf(LocalDate.now()));
		Customer cust = repo.getCustomer(cid);
		feedback.setCustomer(cust);
		Product p = repo.getProduct(pid);
		List<FeedBack> f = p.getFeedback();
		f.add(feedback);
		
		//repo1.save(p);
		
		return repo.save(feedback);

	}

}
