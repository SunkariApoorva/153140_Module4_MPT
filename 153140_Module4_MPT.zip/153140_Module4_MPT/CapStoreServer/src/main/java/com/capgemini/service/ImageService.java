package com.capgemini.service;

import java.util.ArrayList;
import com.capgemini.model.Product;

public interface ImageService {

	public ArrayList<Product> addImage(int productId);

}
