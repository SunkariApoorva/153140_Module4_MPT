package com.capgemini.exception;

public class InvalidStatusException extends Exception {

	public InvalidStatusException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidStatusException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InvalidStatusException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidStatusException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidStatusException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
