package com.capgemini.service;

public interface ServiceInterface {

	
	public String generatePromocode();
	
}
