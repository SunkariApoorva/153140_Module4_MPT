package com.capgemini.service;

import com.capgemini.model.FeedBack;
import com.capgemini.model.Product;

public interface UserFeedBackService {
	public FeedBack getFeedback(int id);

	

	public FeedBack giveFeedback(FeedBack feedback, int pid, int cid);
	
	

}
