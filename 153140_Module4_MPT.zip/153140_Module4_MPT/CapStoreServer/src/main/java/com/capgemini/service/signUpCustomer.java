package com.capgemini.service;

import com.capgemini.model.Customer;
import com.capgemini.model.Merchant;

public interface signUpCustomer {
	public String addCustomer(Customer customer);

}
