package com.capgemini.service;

import com.capgemini.model.Discount;

public interface ApplyDiscountInterface {

		public Discount appplyDiscount(Discount discount);
}
